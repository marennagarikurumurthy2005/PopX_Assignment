import React from 'react'; // adjust path as needed


const AccountSettings = () => {
  return (
    <div className="account-settings-container">
      <h2>Account Settings</h2>
      <div className="account-card">
        <div className="profile-wrapper">
          <img src='./profile.jpg' alt="Profile" className="profile-image" />
          <div className="camera-icon">📷</div>
        </div>
        <div className="user-info">
          <h3>Marry Doe</h3>
          <p className="email">Marry@Gmail.Com</p>
          <p className="description">
            Lorem Ipsum Dolor Sit Amet, Consetetur Sadipscing Elitr, Sed Diam Nonumy Eirmod Tempor Invidunt Ut Labore Et Dolore Magna Aliquyam Erat, Sed Diam
          </p>
        </div>
      </div>
    </div>
  );
};

export default AccountSettings;
