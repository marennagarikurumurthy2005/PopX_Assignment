import React from 'react';
import { useNavigate } from 'react-router-dom';


const Welcome = () => {
  const navigate = useNavigate();

  return (
    <div className="welcome-container">
      <div className="welcome-box">
        <h1>Welcome to PopX</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,</p>

        <button className="create-btn" onClick={() => navigate('/register')}>
          Create Account
        </button>

        <button className="login-btn" onClick={() => navigate('/login')}>
          Already Registered? Login
        </button>

        <button className="settings-btn" onClick={() => navigate('/settings')}>
          Account Settings
        </button>
      </div>
    </div>
  );
};

export default Welcome;
